# StepStyle Shoes Website

A responsive shoe-store landing page made with plain HTML, CSS and JavaScript.

## Files
- `index.html` — page structure and content
- `style.css` — responsive styling
- `script.js` — mobile navigation, category filters, wishlist hearts, demo cart and newsletter feedback

## Preview locally
Open `index.html` in your browser.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new public repository (for example, `stepstyle-shoes`).
2. Upload `index.html`, `style.css`, and `script.js` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose **main** and **/(root)**, then click **Save**.
6. Wait a few minutes. GitHub will show your published website URL in the Pages section.

## Before publishing
- Replace the sample brand name, products, prices and photos with your own.
- Product images currently use remote Unsplash image URLs, so internet access is required to display them.
- The cart and newsletter are front-end demos only. They do not process payments, save orders or collect email addresses on a server.
