const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const cartCount = document.getElementById("cartCount");
const toast = document.getElementById("toast");
let cartItems = 0;
let toastTimer;

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "×" : "☰";
});
navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.textContent = "☰";
}));

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}

document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelector(".filter.active").classList.remove("active");
    button.classList.add("active");
    const filter = button.dataset.filter;
    let visible = 0;
    document.querySelectorAll(".product-card").forEach(card => {
      const show = filter === "all" || card.dataset.category === filter;
      card.hidden = !show;
      if (show) visible++;
    });
    document.getElementById("productCount").textContent = `${String(visible).padStart(2,"0")} PRODUCTS`;
  });
});

document.querySelectorAll(".add-button").forEach(button => {
  button.addEventListener("click", () => {
    cartItems++;
    cartCount.textContent = cartItems;
    showToast(`${button.dataset.name} added to your bag`);
  });
});
document.getElementById("cartButton").addEventListener("click", () => {
  showToast(cartItems ? `Your bag has ${cartItems} item${cartItems === 1 ? "" : "s"}.` : "Your bag is empty — find your fit!");
});

document.querySelectorAll(".heart").forEach(button => {
  button.addEventListener("click", () => {
    button.classList.toggle("liked");
    button.textContent = button.classList.contains("liked") ? "♥" : "♡";
  });
});

document.getElementById("newsletterForm").addEventListener("submit", event => {
  event.preventDefault();
  const email = document.getElementById("emailInput");
  document.getElementById("formMessage").textContent = `Thanks! ${email.value} has been added to this demo list.`;
  email.value = "";
});
